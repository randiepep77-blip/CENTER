# Glass Control Center (Galaxy A05, Android 12+)

Control Center ala iOS glass: geser ke bawah dari pojok kanan atas layar.

## Build
- Android Studio: File > Open folder ini > Run (Gradle wrapper dibuat otomatis).
- Tanpa PC: upload folder ke GitHub, tab Actions > Build APK > unduh `app-debug.apk`.

## Setelah install
1. Buka app > Info aplikasi > menu ⋮ > "Izinkan pengaturan terbatas" (Android 13+, wajib untuk APK hasil sideload).
2. Aktifkan layanan Aksesibilitas "Glass Control Center".
3. Izinkan akses notifikasi (untuk kontrol musik) dan "Ubah setelan sistem" (kecerahan & kunci rotasi).

## Yang bisa / tidak bisa
- Langsung: senter, volume, kecerahan, kunci rotasi, kalkulator, kamera, kontrol musik.
- WiFi / Bluetooth / Mode pesawat / Data: Android 10+ melarang app biasa menyalakan langsung, jadi tombolnya membuka panel/setelan sistem; statusnya tetap tampil.
- Blur memakai FLAG_BLUR_BEHIND (Android 12+). Jika perangkat menonaktifkan blur, otomatis jadi dim gelap.
