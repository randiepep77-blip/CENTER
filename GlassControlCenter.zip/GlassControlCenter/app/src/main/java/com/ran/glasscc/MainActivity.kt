package com.ran.glasscc

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var statusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }
        col.addView(label("Glass Control Center", 26f, bold = true))
        col.addView(label("Geser ke bawah dari pojok kanan atas layar untuk membuka Control Center.", 14f))
        statusTv = label("", 15f)
        statusTv.setPadding(0, dp(12), 0, dp(12))
        col.addView(statusTv)

        col.addView(button("1. Aktifkan layanan Aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("2. Izinkan akses notifikasi (kontrol musik)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("3. Izinkan ubah setelan sistem (kecerahan & rotasi)") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(button("4. Tampil di atas aplikasi lain (opsional)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("Info aplikasi (untuk 'Izinkan pengaturan terbatas')") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0B0B10.toInt())
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        fun mark(ok: Boolean) = if (ok) "✅" else "⬜"
        val acc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        val notif = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        statusTv.text = "${mark(acc)} Aksesibilitas\n" +
            "${mark(notif)} Akses notifikasi (musik)\n" +
            "${mark(Settings.System.canWrite(this))} Ubah setelan sistem\n" +
            "${mark(Settings.canDrawOverlays(this))} Di atas aplikasi lain (opsional)"
    }

    private fun label(text: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(0, 0, 0, dp(8))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) }
    }
}
