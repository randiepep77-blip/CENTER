package com.ran.glasscc

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.PixelFormat
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Menaruh strip tipis tak terlihat di pojok kanan atas layar.
 * Geser ke bawah dari strip itu -> Control Center glass muncul.
 */
class GlassAccessibilityService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private var trigger: View? = null
    private var panel: ControlCenterPanel? = null
    private var shownAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addTrigger()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addTrigger() {
        if (trigger != null) return
        val v = View(this)
        var startY = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!fired && e.rawY - startY > dp(36)) {
                        fired = true
                        showPanel()
                    }
                }
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            dp(170), dp(26),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END }
        wm.addView(v, lp)
        trigger = v
    }

    private fun showPanel() {
        if (panel != null) return
        shownAt = SystemClock.uptimeMillis()
        panel = ControlCenterPanel(this, wm) { panel = null }.also { it.show() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        // Tutup panel kalau ada jendela aplikasi lain yang tampil (mis. pindah app / home)
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            e.packageName != packageName &&
            SystemClock.uptimeMillis() - shownAt > 700
        ) {
            panel?.dismiss()
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        panel?.forceClose()
        panel = null
        trigger?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        trigger = null
    }
}
