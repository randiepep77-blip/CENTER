package com.ran.glasscc

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View

/** Slider vertikal ala iOS: kapsul glass, isi putih naik dari bawah. */
@SuppressLint("ViewConstructor")
class GlassSlider(
    context: Context,
    iconRes: Int,
    private val onChange: (Float) -> Unit
) : View(context) {

    var progress: Float = 0.5f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2FFFFFF.toInt() }
    private val clip = Path()
    private val icon = context.getDrawable(iconRes)!!.mutate()
    private val radius = context.dp(28).toFloat()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        clip.reset()
        clip.addRoundRect(0f, 0f, w.toFloat(), h.toFloat(), radius, radius, Path.Direction.CW)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.save()
        canvas.clipPath(clip)
        canvas.drawRect(0f, 0f, w, h, track)
        canvas.drawRect(0f, h * (1f - progress), w, h, fill)
        canvas.restore()

        val size = context.dp(26)
        val left = ((w - size) / 2f).toInt()
        val top = (h - size - context.dp(18)).toInt()
        icon.setBounds(left, top, left + size, top + size)
        val overFill = top + size / 2f > h * (1f - progress)
        icon.setTint(if (overFill) 0xFF444444.toInt() else 0xCCFFFFFF.toInt())
        icon.draw(canvas)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                progress = 1f - e.y / height
                onChange(progress)
            }
        }
        return true
    }
}
