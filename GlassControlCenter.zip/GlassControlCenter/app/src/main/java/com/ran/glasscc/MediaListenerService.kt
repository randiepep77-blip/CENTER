package com.ran.glasscc

import android.service.notification.NotificationListenerService

/**
 * Kosong dengan sengaja: cukup dengan layanan ini aktif (akses notifikasi),
 * Android mengizinkan aplikasi membaca sesi media aktif (judul, artis, play/pause).
 */
class MediaListenerService : NotificationListenerService()
