package com.ran.glasscc

import android.animation.ValueAnimator
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

/**
 * Jendela overlay Control Center. Efek glass:
 *  - Android 12+ : blur jendela di belakang (FLAG_BLUR_BEHIND) kalau perangkat mengizinkan
 *  - selain itu : dim gelap sebagai cadangan
 * Kartu & tombol memakai fill putih transparan + garis tepi tipis.
 */
class ControlCenterPanel(
    private val ctx: Context,
    private val wm: WindowManager,
    private val onClosed: () -> Unit
) {
    private companion object {
        const val OFF_BG = 0x40FFFFFF
        val ON_WHITE = Color.WHITE
        val BLUE = 0xFF0A84FF.toInt()
        val GREEN = 0xFF30D158.toInt()
        val ORANGE = 0xFFFF9F0A.toInt()
        val RED = 0xFFFF453A.toInt()
        val DARK = 0xFF222222.toInt()
        const val BLUR_RADIUS = 60
    }

    private val handler = Handler(Looper.getMainLooper())
    private val root = FrameLayout(ctx)
    private val content = LinearLayout(ctx)
    private var closing = false
    private var attached = false

    private val blurOn: Boolean =
        Build.VERSION.SDK_INT >= 31 && try { wm.isCrossWindowBlurEnabled } catch (_: Throwable) { false }

    private val lp = WindowManager.LayoutParams(
        MATCH_PARENT, MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cam = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val camId: String? = try {
        cam.cameraIdList.firstOrNull {
            cam.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    } catch (_: Exception) { null }
    private var torchOn = false
    private var controller: MediaController? = null
    private var askedWrite = false

    private lateinit var airplaneBtn: ImageView
    private lateinit var dataBtn: ImageView
    private lateinit var wifiBtn: ImageView
    private lateinit var btBtn: ImageView
    private lateinit var rotateBtn: ImageView
    private lateinit var torchBtn: ImageView
    private lateinit var calcBtn: ImageView
    private lateinit var camBtn: ImageView
    private lateinit var titleTv: TextView
    private lateinit var artistTv: TextView
    private lateinit var playBtn: ImageView

    // ---------------------------------------------------------------- lifecycle

    fun show() {
        build()
        if (blurOn) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 0
        }
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        root.alpha = 0f
        content.alpha = 0f
        content.translationY = -ctx.dp(40).toFloat()
        wm.addView(root, lp)
        attached = true

        root.animate().alpha(1f).setDuration(220).start()
        content.animate().alpha(1f).translationY(0f).setDuration(300)
            .setInterpolator(DecelerateInterpolator()).start()
        if (blurOn) animateBlur(0, BLUR_RADIUS)

        registerTorch()
        startMedia()
        refreshStates()
    }

    fun dismiss() {
        if (closing) return
        closing = true
        stopMedia()
        unregisterTorch()
        if (blurOn) animateBlur(BLUR_RADIUS, 0)
        content.animate().alpha(0f).translationY(-ctx.dp(30).toFloat()).setDuration(200).start()
        root.animate().alpha(0f).setDuration(220).withEndAction {
            remove()
            onClosed()
        }.start()
    }

    fun forceClose() {
        closing = true
        stopMedia()
        unregisterTorch()
        remove()
    }

    private fun remove() {
        if (attached) {
            try { wm.removeView(root) } catch (_: Exception) {}
            attached = false
        }
    }

    private fun animateBlur(from: Int, to: Int) {
        ValueAnimator.ofInt(from, to).apply {
            duration = 260
            addUpdateListener {
                if (!attached) return@addUpdateListener
                lp.blurBehindRadius = it.animatedValue as Int
                try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
            }
            start()
        }
    }

    // ---------------------------------------------------------------- UI

    private fun build() {
        root.setBackgroundColor(if (blurOn) 0x33000000 else 0x99000000.toInt())
        // ketuk area kosong / lepas jari di luar kartu -> tutup
        root.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) dismiss()
            true
        }

        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ctx.dp(20), ctx.dp(56), ctx.dp(20), 0)
        root.addView(content, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP))

        // ---- baris 1: konektivitas + media
        airplaneBtn = tile(R.drawable.ic_airplane) { launch(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        dataBtn = tile(R.drawable.ic_signal) { launch(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
        wifiBtn = tile(R.drawable.ic_wifi) { launch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        btBtn = tile(R.drawable.ic_bluetooth) { launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }

        val row1 = LinearLayout(ctx)
        row1.addView(
            gridCard(airplaneBtn, dataBtn, wifiBtn, btBtn),
            LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginEnd = ctx.dp(6) }
        )
        row1.addView(
            buildMediaCard(),
            LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginStart = ctx.dp(6) }
        )
        content.addView(row1, LinearLayout.LayoutParams(MATCH_PARENT, ctx.dp(160)))

        // ---- baris 2: pintasan + slider
        rotateBtn = tile(R.drawable.ic_lock) { toggleRotationLock() }
        torchBtn = tile(R.drawable.ic_flashlight) { toggleTorch() }
        calcBtn = tile(R.drawable.ic_calculator) {
            launch(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
        }
        camBtn = tile(R.drawable.ic_camera) { launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }

        val bright = GlassSlider(ctx, R.drawable.ic_brightness) { setBrightness(it) }
        bright.progress = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
        val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val vol = GlassSlider(ctx, R.drawable.ic_volume) {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * maxVol).roundToInt(), 0)
        }
        vol.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol

        val sliders = LinearLayout(ctx)
        sliders.addView(bright, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginEnd = ctx.dp(6) })
        sliders.addView(vol, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginStart = ctx.dp(6) })

        val row2 = LinearLayout(ctx)
        row2.addView(
            gridCard(rotateBtn, torchBtn, calcBtn, camBtn),
            LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginEnd = ctx.dp(6) }
        )
        row2.addView(sliders, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginStart = ctx.dp(6) })
        content.addView(
            row2,
            LinearLayout.LayoutParams(MATCH_PARENT, ctx.dp(160)).apply { topMargin = ctx.dp(12) }
        )
    }

    private fun glass(radiusDp: Int = 28): GradientDrawable = GradientDrawable().apply {
        cornerRadius = ctx.dp(radiusDp).toFloat()
        setColor(OFF_BG)
        setStroke(ctx.dp(1), 0x33FFFFFF)
    }

    private fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = glass()
        isClickable = true // supaya ketukan di kartu tidak menutup panel
    }

    private fun gridCard(a: View, b: View, c: View, d: View): LinearLayout {
        val card = card()
        val r1 = LinearLayout(ctx).apply { addView(cell(a)); addView(cell(b)) }
        val r2 = LinearLayout(ctx).apply { addView(cell(c)); addView(cell(d)) }
        card.addView(r1, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        card.addView(r2, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        return card
    }

    private fun cell(child: View): FrameLayout = FrameLayout(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
        addView(child, FrameLayout.LayoutParams(ctx.dp(52), ctx.dp(52), Gravity.CENTER))
    }

    private fun tile(icon: Int, onClick: () -> Unit): ImageView = ImageView(ctx).apply {
        setImageResource(icon)
        val p = ctx.dp(14)
        setPadding(p, p, p, p)
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(OFF_BG)
        }
        imageTintList = ColorStateList.valueOf(Color.WHITE)
        setOnClickListener { onClick() }
    }

    private fun setOn(v: ImageView, on: Boolean, color: Int = ON_WHITE) {
        (v.background as GradientDrawable).setColor(if (on) color else OFF_BG)
        val darkIcon = on && color == ON_WHITE
        v.imageTintList = ColorStateList.valueOf(if (darkIcon) DARK else Color.WHITE)
    }

    private fun buildMediaCard(): LinearLayout {
        val c = card()
        c.setPadding(ctx.dp(16), ctx.dp(16), ctx.dp(16), ctx.dp(8))

        titleTv = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            text = "Tidak ada media"
        }
        artistTv = TextView(ctx).apply {
            setTextColor(0xB3FFFFFF.toInt())
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val controls = LinearLayout(ctx).apply { gravity = Gravity.CENTER }
        val prev = mediaCtrl(R.drawable.ic_prev) { controller?.transportControls?.skipToPrevious() }
        playBtn = mediaCtrl(R.drawable.ic_play) {
            val c2 = controller
            if (c2 == null) {
                Toast.makeText(ctx, "Putar musik dulu & aktifkan akses notifikasi", Toast.LENGTH_SHORT).show()
            } else if (c2.playbackState?.state == PlaybackState.STATE_PLAYING) {
                c2.transportControls.pause()
            } else {
                c2.transportControls.play()
            }
        }
        val next = mediaCtrl(R.drawable.ic_next) { controller?.transportControls?.skipToNext() }
        controls.addView(prev); controls.addView(playBtn); controls.addView(next)

        c.addView(titleTv)
        c.addView(artistTv)
        c.addView(View(ctx), LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        c.addView(controls, LinearLayout.LayoutParams(MATCH_PARENT, ctx.dp(44)))
        return c
    }

    private fun mediaCtrl(icon: Int, onClick: () -> Unit): ImageView = ImageView(ctx).apply {
        setImageResource(icon)
        val p = ctx.dp(8)
        setPadding(p, p, p, p)
        imageTintList = ColorStateList.valueOf(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
        setOnClickListener { onClick() }
    }

    // ---------------------------------------------------------------- state & aksi

    private fun refreshStates() {
        val cr = ctx.contentResolver
        setOn(airplaneBtn, Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1, ORANGE)

        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cellular = cm.getNetworkCapabilities(cm.activeNetwork)
                ?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            setOn(dataBtn, cellular, GREEN)
        } catch (_: Exception) {}

        try {
            val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            setOn(wifiBtn, wifi.isWifiEnabled, BLUE)
        } catch (_: Exception) {}

        try {
            val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            setOn(btBtn, bt?.isEnabled == true, BLUE)
        } catch (_: Exception) {}

        setOn(rotateBtn, Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1) == 0, RED)
        setOn(torchBtn, torchOn)
    }

    private fun writeSettingsIntent() =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))

    private fun toggleRotationLock() {
        if (!Settings.System.canWrite(ctx)) {
            launch(writeSettingsIntent())
            return
        }
        val cr = ctx.contentResolver
        val locked = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, if (locked) 1 else 0)
        refreshStates()
    }

    private fun setBrightness(p: Float) {
        if (!Settings.System.canWrite(ctx)) {
            if (!askedWrite) {
                askedWrite = true
                Toast.makeText(ctx, "Izinkan 'Ubah setelan sistem' dulu", Toast.LENGTH_LONG).show()
                launch(writeSettingsIntent())
            }
            return
        }
        val cr = ctx.contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (p * 255).roundToInt().coerceIn(1, 255))
    }

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == camId) {
                torchOn = enabled
                setOn(torchBtn, enabled)
            }
        }
    }

    private fun registerTorch() {
        try { cam.registerTorchCallback(torchCb, handler) } catch (_: Exception) {}
    }

    private fun unregisterTorch() {
        try { cam.unregisterTorchCallback(torchCb) } catch (_: Exception) {}
    }

    private fun toggleTorch() {
        val id = camId ?: return
        try { cam.setTorchMode(id, !torchOn) } catch (_: Exception) {}
    }

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(ctx, "Tidak bisa dibuka", Toast.LENGTH_SHORT).show()
        }
        dismiss()
    }

    // ---------------------------------------------------------------- media

    private val mediaCb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = updateMedia()
        override fun onPlaybackStateChanged(state: PlaybackState?) = updateMedia()
    }

    private fun listenerEnabled(): Boolean =
        Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?.contains(ctx.packageName) == true

    private fun startMedia() {
        controller = try {
            ctx.getSystemService(MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(ctx, MediaListenerService::class.java))
                .firstOrNull()
        } catch (_: SecurityException) { null }
        controller?.registerCallback(mediaCb, handler)
        updateMedia()
    }

    private fun stopMedia() {
        try { controller?.unregisterCallback(mediaCb) } catch (_: Exception) {}
        controller = null
    }

    private fun updateMedia() {
        val c = controller
        if (c == null) {
            titleTv.text = if (listenerEnabled()) "Tidak ada media" else "Aktifkan akses notifikasi"
            artistTv.text = ""
            playBtn.setImageResource(R.drawable.ic_play)
            return
        }
        titleTv.text = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Tanpa judul"
        artistTv.text = c.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }
}
